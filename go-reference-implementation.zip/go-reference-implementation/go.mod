module github.com/sangmdas/Hardened-Challenge-Bound-Execution-Finality-for-AI-Interoperability/go-reference-implementation

go 1.22
