# Specification-to-Code Mapping

| Architectural concept | Go implementation |
|---|---|
| Candidate Act | `finality.CandidateAct` |
| Non-Effective State | no external effect is committed before `FinalitySink.Finalize` succeeds |
| Protected validation | `ProtectedValidator.IssueAuthority` |
| LAVR / protected validation evidence | signed LAVR generated in `validator.go` |
| Bounded non-bearer capability | signed capability generated in `validator.go` |
| Current protected state | `ProtectedState` + `PolicyState` |
| Actual-effect reconstruction | `ActualEffect.Reconstruct` |
| Finality Sink | `FinalitySink` |
| Fresh sink challenge | `FinalitySink.IssueChallenge` |
| Live requester presentation | `CreatePresentation` |
| Exact-effect binding | Candidate Act commitment equals reconstructed effect commitment |
| Protected-channel context | SHA-256 digest of caller-supplied channel binding |
| Replay/single use | issued/challenge state consumed under mutex |
| Revocation | `ProtectedState.Revoke` and re-checks before final commit |
| Strict serialization | `EncodeCBOR` / `DecodeCBOR` |
| Signed security objects | `Sign1` / `Verify1` |

The architecture and broader discussion are maintained in the associated IETF Internet-Draft:

https://datatracker.ietf.org/doc/draft-das-execution-finality-ai-interoperability/
