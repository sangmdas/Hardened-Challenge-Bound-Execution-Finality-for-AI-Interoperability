package main

import (
	"crypto/ed25519"
	"crypto/rand"
	"fmt"
	"log"
	"time"

	f "github.com/sangmdas/Hardened-Challenge-Bound-Execution-Finality-for-AI-Interoperability/go-reference-implementation/finality"
)

func main() {
	validatorPub, validatorPriv, _ := ed25519.GenerateKey(rand.Reader)
	requesterPub, requesterPriv, _ := ed25519.GenerateKey(rand.Reader)
	state := f.NewProtectedState()
	policy := f.PolicyState{Version: 7, SecurityEpoch: 11, RevocationEpoch: 3, AllowedActions: map[string]bool{"message.send": true}, AllowedDestinationApps: map[string]bool{"system.messages": true}}
	now := time.Now().Unix()
	effect := f.ActualEffect{Requester: "assistant.example", Action: "message.send", Resource: []byte("hello"), Destination: "alice@example.com", DestinationApp: "system.messages", FinalitySink: "urn:device:sink:messages", Boundary: "messages-send-boundary", SessionID: "session-123", UserIntentDigest: f.Digest([]byte("confirmed")), PolicyVersion: 7, SecurityEpoch: 11, RevocationEpoch: 3, Nonce: []byte("0123456789abcdef"), IssuedAt: now - 1, ExpiresAt: now + 30, ActID: "demo-act-1"}
	validator := &f.ProtectedValidator{Key: validatorPriv, KID: []byte("validator-1"), RequesterKeys: map[string]ed25519.PublicKey{"assistant.example": requesterPub}, State: state, Policy: policy}
	sink := &f.FinalitySink{SinkID: effect.FinalitySink, Boundary: effect.Boundary, ValidatorKeys: map[string]ed25519.PublicKey{"validator-1": validatorPub}, RequesterKeys: map[string]ed25519.PublicKey{"requester-1": requesterPub}, State: state, PolicyProvider: func() f.PolicyState { return policy }}
	bundle, err := validator.IssueAuthority(effect.Reconstruct(), true, now)
	if err != nil {
		log.Fatal(err)
	}
	channel := []byte("protected-channel-binding-demo")
	challenge, err := sink.IssueChallenge(effect, bundle, channel, now, 5)
	if err != nil {
		log.Fatal(err)
	}
	presentation, err := f.CreatePresentation(bundle.Capability, effect, challenge, channel, requesterPriv, []byte("requester-1"))
	if err != nil {
		log.Fatal(err)
	}
	result, err := sink.Finalize(effect, bundle, challenge, presentation, channel, now)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Println(result)
}
