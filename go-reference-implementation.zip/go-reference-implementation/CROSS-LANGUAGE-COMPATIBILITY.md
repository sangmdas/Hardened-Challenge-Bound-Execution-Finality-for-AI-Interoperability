# Python ↔ Go Compatibility Notes

The hardened Python implementation and this Go implementation are separate codebases and runtimes. The Go code does not import, call, embed, or invoke Python.

To test a concrete cross-language property, deterministic vectors were generated from the Python hardened implementation for:

- deterministic CBOR encoding; and
- the strict Ed25519 COSE_Sign1 profile.

The vectors are stored in `testdata/python_vectors.json` and hard-checked by the Go test suite.

## Verified vector 1 — deterministic CBOR

Logical object:

```text
{1:2, 2:"abc", 3:h'010203', 4:["x",7,true]}
```

Expected bytes:

```text
a40102026361626303430102030483617807f5
```

## Verified vector 2 — COSE_Sign1 / Ed25519

Fixed 32-byte Ed25519 seed:

```text
000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f
```

KID: `kid`  
Payload: `payload`

Expected token:

```text
8448a2012704436b6964a0477061796c6f61645840a8be91d73412f8f3876d9a52eb045c38ff20964fe626c6950bb246526406386d0b627bbeddf7bf90dfdfbe2c9e646aa2c7b986e7d78a60691247e94cd01a4e0d
```

These vectors show byte-for-byte agreement for the tested primitives. They should be extended when the profile introduces new object types, headers, algorithms, or serialization rules.
