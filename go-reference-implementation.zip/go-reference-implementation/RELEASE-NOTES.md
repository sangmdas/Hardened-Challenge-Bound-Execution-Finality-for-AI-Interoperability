# Release Notes — Go Reference Implementation 0.1.0

This release adds a second-language implementation of the hardened challenge-bound execution-finality profile.

## What is new

- Go implementation with no external Go module dependencies.
- Strict deterministic CBOR subset.
- Minimal strict COSE_Sign1 Ed25519 implementation.
- Candidate Act / LAVR / capability / challenge / live presentation flow.
- Exact-effect and protected-channel binding.
- Single-use synchronized reference state.
- Concurrency test for competing first-use finality attempts.
- 41 executable Go tests.
- Python↔Go deterministic compatibility vectors.
- GitHub Actions matrix for Go 1.22/1.23 on Ubuntu, macOS, and Windows, plus an Ubuntu race-detector job.

The CI matrix is configuration, not evidence of successful CI execution until the workflow actually runs on GitHub.
