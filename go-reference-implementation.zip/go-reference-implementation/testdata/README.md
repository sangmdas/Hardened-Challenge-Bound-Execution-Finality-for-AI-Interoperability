# Test Data

`python_vectors.json` records fixed deterministic vectors produced by the hardened Python implementation and consumed as compatibility evidence by the Go implementation.

The security tests do not depend on a Python runtime.
