# Security Invariants and Boundaries — Go Reference Implementation

## Enforced by this code

For a successful reference finality operation, the Go implementation verifies:

- the Candidate Act is structurally valid and within its validity interval;
- current policy permits the action and destination application;
- policy, security, and revocation epochs match current protected state;
- LAVR and capability signatures verify under an accepted validator key;
- LAVR and capability use the same validator key identifier;
- LAVR and capability contain exactly the expected signed fields;
- LAVR predicates exactly match the profile-required predicate set;
- the capability digest binds the exact LAVR;
- LAVR and capability bind the same Candidate Act commitment;
- the reconstructed actual effect produces that same commitment;
- requester and nonce agree across protected evidence, capability, and actual effect;
- sink and boundary agree across all security objects and local Finality Sink identity;
- validation time equals capability issuance time;
- the authority is not used before issuance or after expiry;
- `permitted_effect_count` is exactly one;
- the requester key thumbprint is bound into the capability;
- a fresh sink-issued challenge exists within its bounded lifetime;
- the challenge binds capability digest, actual effect, sink, boundary, channel binding, and capability ID;
- the requester signs a live presentation binding that challenge to the exact effect;
- revocation is checked again before final commit; and
- capability/challenge consumption is single-use under the synchronized reference state store.

## Fail-closed behavior

Malformed CBOR, non-deterministic encodings, unsupported COSE fields, unknown keys, invalid signatures, missing/extra signed fields, stale state, mismatched effect parameters, replay, and challenge/presentation substitution result in denial.

## Not established by this portable Go code

The implementation does not establish hardware key custody, trusted OS channel provenance, rollback-resistant persistence, complete path mediation, trusted human-intent capture, or atomicity with arbitrary remote physical/network effects.

The in-memory `ProtectedState` is a reference state machine. It is not a secure-element persistence service.
