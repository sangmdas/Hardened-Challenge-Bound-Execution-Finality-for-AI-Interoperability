# Known Limitations

1. **Reference state is in memory.** It demonstrates single-use and concurrent-consumption semantics within the running process, but it is not durable or rollback resistant.
2. **No hardware key custody.** Go Ed25519 private keys are software keys in this implementation.
3. **Channel binding is supplied by the caller.** The code verifies the binding cryptographically but cannot prove that the bytes came from protected IPC, a kernel audit token, a TEE, or a secure processor.
4. **No complete OS-path mediation.** Alternate egress paths must be brought under equivalent Finality-Sink enforcement by the production platform.
5. **Human intent is an interface input.** This implementation does not itself produce protected biometric/secure-screen evidence.
6. **Time source is supplied as an integer timestamp.** Production deployments need an appropriate trustworthy time/freshness source for their threat model.
7. **External-effect atomicity is not solved.** The reference state can atomically decide one local commit, but cannot place an arbitrary radio transmission, payment rail, or remote service in the same memory transaction.
8. **Compatibility vectors are finite.** Exact matches for included deterministic vectors do not prove compatibility for unspecified future extensions.
9. **No production performance claim.** The tests are correctness/security-semantics tests, not iPhone/Android latency or battery benchmarks.
