# Go Reference Implementation — Challenge-Bound Execution Finality for AI Interoperability

**Second-language implementation inside the hardened repository — Go**

This subdirectory is a separate Go implementation of the hardened execution-finality profile for AI interoperability. It is **not a Python binding, wrapper, or subprocess adapter**. The implementation uses the Go standard library for Ed25519, SHA-256, concurrency, and the in-memory protected-state model, and contains its own strict deterministic CBOR and minimal COSE_Sign1 implementation.

The purpose of this repository is to test whether the security semantics can be implemented in a second programming language/runtime while preserving the same load-bearing behavior:

`Candidate Act -> Non-Effective State -> Protected Validation -> signed LAVR -> signed bounded capability -> Finality Sink reconstructs actual effect -> fresh sink challenge -> live requester presentation -> strict cross-object verification -> single-use consumption -> effect commit`

## Related implementations and specification

**Initial runnable Python implementation**  
https://github.com/sangmdas/Secure-and-Privacy-Preserving-AI-Interoperability-for-Third-Party-Tools

**Hardened Python implementation**  
https://github.com/sangmdas/Hardened-Challenge-Bound-Execution-Finality-for-AI-Interoperability

**IETF Internet-Draft**  
https://datatracker.ietf.org/doc/draft-das-execution-finality-ai-interoperability/

This Go implementation does not define a new architecture. It is a second-language implementation intended to expose parser, serialization, state-machine, concurrency, and cryptographic assumptions that can remain hidden when only one language implementation exists.

## Language and dependencies

- Language: **Go**
- Module target: Go **1.22+**
- Tested locally with: **Go 1.23.2**
- External Go modules: **none**
- Cryptography: `crypto/ed25519`, `crypto/sha256`
- Security-object serialization: strict deterministic CBOR subset implemented in `finality/cbor.go`
- Signature container: minimal strict COSE_Sign1 Ed25519 profile implemented in `finality/cose.go`
- Protected-state reference backend: synchronized in-memory state machine in `finality/state.go`

No Python runtime is required to build, run, or test this repository.

## Run the implementation

```bash
go test ./...
go run ./cmd/demo
```

Expected demo output:

```text
EFFECT_COMMITTED
```

For race detection:

```bash
go test -race ./...
```

## What is implemented

The Go implementation includes:

- Candidate Act construction and deterministic commitment;
- exact-effect reconstruction from the proposed external consequence;
- policy/security/revocation epoch checks;
- signed LAVR generation;
- signed single-use execution capability generation;
- requester public-key thumbprint binding;
- strict deterministic CBOR parsing;
- minimal strict COSE_Sign1 with Ed25519;
- exact signed-field-set validation;
- LAVR-to-capability digest binding;
- Candidate Act / LAVR / capability / actual-effect cross-checking;
- explicit not-before and expiry enforcement;
- fresh Finality-Sink challenge generation;
- short challenge lifetime enforcement;
- protected-channel-binding digest binding;
- live requester-key proof over the challenge and actual effect;
- revocation re-check before final commit;
- single-use capability and challenge state;
- concurrent first-use protection within the reference state store; and
- deterministic Python↔Go CBOR/COSE compatibility vectors.

## Executable tests

The repository currently contains **41 Go tests** covering the success path, replay, field substitution, strict schemas, malformed/non-canonical CBOR, COSE signature tampering, freshness, revocation, challenge binding, protected-channel binding, concurrency, nonce/act reuse, and cross-language deterministic vectors.

The recorded local run completed successfully with:

```bash
go test ./...
go test -race ./...
```

See `TEST-REPORT.md` for the recorded environment and interpretation boundaries.

## Cross-language compatibility

`testdata/python_vectors.json` contains deterministic CBOR and COSE_Sign1 vectors generated using the hardened Python reference implementation. The Go suite verifies that its independently written encoder/signature profile produces the same bytes for those fixed inputs.

This demonstrates compatibility for the tested deterministic primitives. It does **not** by itself prove complete interoperability for every future object/profile extension. See `CROSS-LANGUAGE-COMPATIBILITY.md`.

## What this does not prove

This is a portable reference implementation. It does **not** establish:

- Apple Secure Enclave or Android StrongBox integration;
- hardware-backed requester-key custody;
- trusted derivation of `protected_channel_binding`;
- rollback-resistant persistent state;
- complete mediation of every OS/network/device egress path;
- protected human-intent evidence;
- trusted hardware time;
- atomicity with an arbitrary irreversible remote side effect;
- production mobile latency, battery, throughput, or regulatory compliance.

The in-memory state store deliberately makes the protocol/state-machine logic easy to inspect. Production state must be mapped to an appropriate protected persistence mechanism when the threat model requires rollback resistance or crash recovery.

## Why a second language matters

A second implementation is useful because interoperability failures often appear in places that a single codebase cannot reveal, including:

- canonical serialization differences;
- integer representation;
- map ordering;
- signature-container interpretation;
- parser strictness;
- missing/extra-field handling;
- time-boundary behavior;
- concurrency and state-consumption semantics; and
- silent downgrade behavior.

The Go implementation therefore functions as an additional falsification surface for the specification rather than as additional evidence merely because it is written in another language.

## Central invariant

> Computation may generate or prepare an operation, but computation is not authority. A consequential operation remains non-effective until the Finality Sink verifies the complete, current, challenge-bound, effect-specific authorization state immediately before effectuation.

## License and patent rights

Repository copyright material is provided under the terms stated in `LICENSE`. The copyright license does **not** grant a patent license. Patent rights are expressly reserved as described there. IETF contribution material remains subject to applicable IETF Trust and contribution rules.
