# Associated Internet-Draft

The current specification is maintained through the IETF Datatracker:

https://datatracker.ietf.org/doc/draft-das-execution-finality-ai-interoperability/

This Go repository intentionally links to the maintained draft instead of embedding a potentially stale XML snapshot. The Go implementation is a separate executable reference implementation and does not alter the Internet-Draft's IETF Trust licensing terms.
