# Go Reference Implementation — Test Report

Date: 2026-09-11

## Recorded environment

```text
go version go1.23.2 linux/amd64
Linux localhost 6.18.35 #1 SMP Mon Aug 31 18:10:37 UTC 2026 x86_64 GNU/Linux
```

## Commands executed

```bash
go test ./...
go test -race ./...
go vet ./...
go run ./cmd/demo
```

## Result

- 41 executable Go tests: PASS
- Race-detector suite: PASS
- `go vet ./...`: PASS
- End-to-end demo: `EFFECT_COMMITTED`

The suite tests reference protocol/security semantics. It is not a production mobile benchmark or certification.
