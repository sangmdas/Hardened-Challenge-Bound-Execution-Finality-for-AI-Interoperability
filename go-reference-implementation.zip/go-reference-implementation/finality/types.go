package finality

import (
	"bytes"
	"crypto/ed25519"
	"crypto/sha256"
	"fmt"
)

const (
	ProfileVersion      int64 = 2
	MaxActLifetime      int64 = 300
	DefaultChallengeTTL int64 = 5
	MaxChallengeTTL     int64 = 30
)

var RequiredPredicates = []string{"destination", "freshness", "policy", "requester", "resource", "revocation", "scope", "user-intent"}

type Denied struct{ Code string }

func (e Denied) Error() string { return e.Code }
func deny(code string) error   { return Denied{Code: code} }

func Digest(data []byte) []byte                  { h := sha256.Sum256(data); return h[:] }
func KeyThumbprint(key ed25519.PublicKey) []byte { return Digest(key) }
func cloneBytes(b []byte) []byte                 { return append([]byte(nil), b...) }
func eq(a, b []byte) bool                        { return bytes.Equal(a, b) }
func validString(s string) bool                  { return len(s) > 0 && len(s) <= 512 }
func validBytes(b []byte, min, max int) bool     { return len(b) >= min && len(b) <= max }
func validUint(v int64) bool                     { return v >= 0 }

func asMap(v any, keys []int64, name string) (CBORMap, error) {
	m, ok := v.(CBORMap)
	if !ok || len(m) != len(keys) {
		return nil, deny("invalid_" + name + "_schema")
	}
	for _, k := range keys {
		if _, ok := m[k]; !ok {
			return nil, deny("invalid_" + name + "_schema")
		}
	}
	return m, nil
}
func ints(from, to int64) []int64 {
	out := make([]int64, 0, to-from+1)
	for i := from; i <= to; i++ {
		out = append(out, i)
	}
	return out
}
func getInt(m CBORMap, k int64, name string) (int64, error) {
	v, ok := m[k].(int64)
	if !ok || !validUint(v) {
		return 0, deny("invalid_" + name)
	}
	return v, nil
}
func getString(m CBORMap, k int64, name string) (string, error) {
	v, ok := m[k].(string)
	if !ok || !validString(v) {
		return "", deny("invalid_" + name)
	}
	return v, nil
}
func getBytes(m CBORMap, k int64, name string, min, max int) ([]byte, error) {
	v, ok := m[k].([]byte)
	if !ok || !validBytes(v, min, max) {
		return nil, deny("invalid_" + name)
	}
	return v, nil
}

type CandidateAct struct {
	Requester        string
	Action           string
	ResourceDigest   []byte
	Destination      string
	DestinationApp   string
	FinalitySink     string
	Boundary         string
	SessionID        string
	UserIntentDigest []byte
	PolicyVersion    int64
	SecurityEpoch    int64
	RevocationEpoch  int64
	Nonce            []byte
	IssuedAt         int64
	ExpiresAt        int64
	ActID            string
}

func (a CandidateAct) Validate() error {
	if !validString(a.Requester) {
		return deny("invalid_requester")
	}
	if !validString(a.Destination) {
		return deny("invalid_destination")
	}
	if !validString(a.DestinationApp) {
		return deny("invalid_destination_app")
	}
	if !validString(a.FinalitySink) {
		return deny("invalid_finality_sink")
	}
	if !validString(a.Boundary) {
		return deny("invalid_boundary")
	}
	if !validString(a.SessionID) {
		return deny("invalid_session_id")
	}
	if !validString(a.ActID) {
		return deny("invalid_act_id")
	}
	switch a.Action {
	case "message.send", "file.export", "app.dispatch":
	default:
		return deny("unsupported_action")
	}
	if !validBytes(a.ResourceDigest, 32, 32) {
		return deny("invalid_resource_digest")
	}
	if !validBytes(a.UserIntentDigest, 32, 32) {
		return deny("invalid_user_intent_digest")
	}
	if !validBytes(a.Nonce, 16, 64) {
		return deny("invalid_nonce")
	}
	if !validUint(a.PolicyVersion) || !validUint(a.SecurityEpoch) || !validUint(a.RevocationEpoch) || !validUint(a.IssuedAt) || !validUint(a.ExpiresAt) {
		return deny("invalid_integer_field")
	}
	if a.ExpiresAt <= a.IssuedAt || a.ExpiresAt-a.IssuedAt > MaxActLifetime {
		return deny("invalid_validity_window")
	}
	return nil
}
func (a CandidateAct) Encode() ([]byte, error) {
	if err := a.Validate(); err != nil {
		return nil, err
	}
	return EncodeCBOR(CBORMap{1: ProfileVersion, 2: a.ActID, 3: a.Requester, 4: a.Action, 5: a.ResourceDigest, 6: a.Destination, 7: a.DestinationApp, 8: a.FinalitySink, 9: a.Boundary, 10: a.SessionID, 11: a.UserIntentDigest, 12: a.PolicyVersion, 13: a.SecurityEpoch, 14: a.RevocationEpoch, 15: a.Nonce, 16: a.IssuedAt, 17: a.ExpiresAt})
}
func (a CandidateAct) Commitment() ([]byte, error) {
	x, e := a.Encode()
	if e != nil {
		return nil, e
	}
	return Digest(x), nil
}

type ActualEffect struct {
	Requester        string
	Action           string
	Resource         []byte
	Destination      string
	DestinationApp   string
	FinalitySink     string
	Boundary         string
	SessionID        string
	UserIntentDigest []byte
	PolicyVersion    int64
	SecurityEpoch    int64
	RevocationEpoch  int64
	Nonce            []byte
	IssuedAt         int64
	ExpiresAt        int64
	ActID            string
}

func (e ActualEffect) Reconstruct() CandidateAct {
	return CandidateAct{e.Requester, e.Action, Digest(e.Resource), e.Destination, e.DestinationApp, e.FinalitySink, e.Boundary, e.SessionID, e.UserIntentDigest, e.PolicyVersion, e.SecurityEpoch, e.RevocationEpoch, e.Nonce, e.IssuedAt, e.ExpiresAt, e.ActID}
}

type PolicyState struct {
	Version, SecurityEpoch, RevocationEpoch int64
	AllowedActions                          map[string]bool
	AllowedDestinationApps                  map[string]bool
}

func (p PolicyState) Validate() error {
	if p.Version < 0 || p.SecurityEpoch < 0 || p.RevocationEpoch < 0 {
		return fmt.Errorf("invalid policy epochs")
	}
	return nil
}

type AuthorityBundle struct{ LAVR, Capability []byte }
type VerifiedAuthority struct {
	LAVR, Capability                      CBORMap
	CapID, ActualCommitment, ValidatorKID []byte
}
