package finality

import (
	"bytes"
	"crypto/ed25519"
	"encoding/hex"
	"testing"
)

func TestDeterministicCBORRoundTrip(t *testing.T) {
	v := CBORMap{1: int64(2), 2: "abc", 3: []byte{1, 2, 3}, 4: []any{"x", int64(7), true, nil}}
	b, e := EncodeCBOR(v)
	if e != nil {
		t.Fatal(e)
	}
	x, e := DecodeCBOR(b)
	if e != nil {
		t.Fatal(e)
	}
	bb, _ := EncodeCBOR(x)
	if !bytes.Equal(b, bb) {
		t.Fatal("roundtrip differs")
	}
}
func TestNonMinimalIntegerRejected(t *testing.T) {
	if _, e := DecodeCBOR([]byte{0x18, 0x17}); e == nil {
		t.Fatal("expected rejection")
	}
}
func TestTrailingDataRejected(t *testing.T) {
	if _, e := DecodeCBOR([]byte{0x01, 0x01}); e == nil {
		t.Fatal("expected rejection")
	}
}
func TestIndefiniteArrayRejected(t *testing.T) {
	if _, e := DecodeCBOR([]byte{0x9f, 0xff}); e == nil {
		t.Fatal("expected rejection")
	}
}
func TestFloatRejected(t *testing.T) {
	if _, e := DecodeCBOR([]byte{0xfa, 0, 0, 0, 0}); e == nil {
		t.Fatal("expected rejection")
	}
}
func TestTagRejected(t *testing.T) {
	if _, e := DecodeCBOR([]byte{0xc0, 0x01}); e == nil {
		t.Fatal("expected rejection")
	}
}
func TestNonCanonicalMapOrderRejected(t *testing.T) {
	b := []byte{0xa2, 0x02, 0x00, 0x01, 0x00}
	if _, e := DecodeCBOR(b); e == nil {
		t.Fatal("expected rejection")
	}
}
func TestCOSESignVerify(t *testing.T) {
	seed := make([]byte, 32)
	for i := range seed {
		seed[i] = byte(i)
	}
	priv := ed25519.NewKeyFromSeed(seed)
	pub := priv.Public().(ed25519.PublicKey)
	tok, e := Sign1([]byte("payload"), priv, []byte("kid"))
	if e != nil {
		t.Fatal(e)
	}
	p, k, e := Verify1(tok, map[string]ed25519.PublicKey{"kid": pub})
	if e != nil {
		t.Fatal(e)
	}
	if string(p) != "payload" || string(k) != "kid" {
		t.Fatal("wrong result")
	}
}
func TestCOSETamperRejected(t *testing.T) {
	seed := make([]byte, 32)
	priv := ed25519.NewKeyFromSeed(seed)
	pub := priv.Public().(ed25519.PublicKey)
	tok, _ := Sign1([]byte("payload"), priv, []byte("kid"))
	tok[len(tok)-1] ^= 1
	if _, _, e := Verify1(tok, map[string]ed25519.PublicKey{"kid": pub}); e == nil {
		t.Fatal("expected rejection")
	}
}
func TestPythonCBORCompatibilityVector(t *testing.T) {
	want := "a40102026361626303430102030483617807f5"
	v := CBORMap{1: int64(2), 2: "abc", 3: []byte{1, 2, 3}, 4: []any{"x", int64(7), true}}
	b, e := EncodeCBOR(v)
	if e != nil {
		t.Fatal(e)
	}
	if hex.EncodeToString(b) != want {
		t.Fatalf("got %x want %s", b, want)
	}
}

func TestPythonCOSECompatibilityVector(t *testing.T) {
	seed := make([]byte, 32)
	for i := range seed {
		seed[i] = byte(i)
	}
	priv := ed25519.NewKeyFromSeed(seed)
	tok, err := Sign1([]byte("payload"), priv, []byte("kid"))
	if err != nil {
		t.Fatal(err)
	}
	want := "8448a2012704436b6964a0477061796c6f61645840a8be91d73412f8f3876d9a52eb045c38ff20964fe626c6950bb246526406386d0b627bbeddf7bf90dfdfbe2c9e646aa2c7b986e7d78a60691247e94cd01a4e0d"
	if hex.EncodeToString(tok) != want {
		t.Fatalf("got %x want %s", tok, want)
	}
}
