package finality

import (
	"crypto/ed25519"
	"crypto/rand"
)

type ProtectedValidator struct {
	Key           ed25519.PrivateKey
	KID           []byte
	RequesterKeys map[string]ed25519.PublicKey
	State         *ProtectedState
	Policy        PolicyState
}

func randomBytes(n int) ([]byte, error) { b := make([]byte, n); _, e := rand.Read(b); return b, e }
func (v *ProtectedValidator) IssueAuthority(act CandidateAct, userIntentVerified bool, now int64) (AuthorityBundle, error) {
	var zero AuthorityBundle
	if err := act.Validate(); err != nil {
		return zero, err
	}
	if !userIntentVerified {
		return zero, deny("user_intent_required")
	}
	pub, ok := v.RequesterKeys[act.Requester]
	if !ok {
		return zero, deny("unknown_requester")
	}
	if !v.Policy.AllowedActions[act.Action] || !v.Policy.AllowedDestinationApps[act.DestinationApp] {
		return zero, deny("policy_denied")
	}
	if act.PolicyVersion != v.Policy.Version || act.SecurityEpoch != v.Policy.SecurityEpoch || act.RevocationEpoch != v.Policy.RevocationEpoch {
		return zero, deny("stale_governance_state")
	}
	if now < act.IssuedAt {
		return zero, deny("candidate_not_yet_valid")
	}
	if now > act.ExpiresAt {
		return zero, deny("candidate_expired")
	}
	if v.State.IsRevoked(act.Requester, act.RevocationEpoch) {
		return zero, deny("requester_revoked")
	}
	commitment, _ := act.Commitment()
	receiptID, e := randomBytes(16)
	if e != nil {
		return zero, e
	}
	preds := make([]any, len(RequiredPredicates))
	for i, x := range RequiredPredicates {
		preds[i] = x
	}
	lavrPayload, e := EncodeCBOR(CBORMap{1: ProfileVersion, 2: receiptID, 3: commitment, 4: act.Requester, 5: act.Nonce, 6: act.PolicyVersion, 7: act.SecurityEpoch, 8: act.RevocationEpoch, 9: act.FinalitySink, 10: act.Boundary, 11: now, 12: preds})
	if e != nil {
		return zero, e
	}
	lavr, e := Sign1(lavrPayload, v.Key, v.KID)
	if e != nil {
		return zero, e
	}
	capID, e := randomBytes(16)
	if e != nil {
		return zero, e
	}
	capPayload, e := EncodeCBOR(CBORMap{1: ProfileVersion, 2: capID, 3: commitment, 4: Digest(lavr), 5: act.Requester, 6: KeyThumbprint(pub), 7: act.FinalitySink, 8: act.Boundary, 9: act.Nonce, 10: act.PolicyVersion, 11: act.SecurityEpoch, 12: act.RevocationEpoch, 13: now, 14: act.ExpiresAt, 15: int64(1)})
	if e != nil {
		return zero, e
	}
	cap, e := Sign1(capPayload, v.Key, v.KID)
	if e != nil {
		return zero, e
	}
	if e = v.State.RecordIssued(capID, act, now); e != nil {
		return zero, e
	}
	return AuthorityBundle{lavr, cap}, nil
}
