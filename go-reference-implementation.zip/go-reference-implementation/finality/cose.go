package finality

import (
	"bytes"
	"crypto/ed25519"
	"fmt"
)

const (
	coseAlg   int64 = 1
	coseKid   int64 = 4
	coseEdDSA int64 = -8
)

type COSEError struct{ Msg string }

func (e COSEError) Error() string { return e.Msg }

func Sign1(payload []byte, privateKey ed25519.PrivateKey, kid []byte) ([]byte, error) {
	if payload == nil {
		return nil, COSEError{"payload must be bytes"}
	}
	if len(kid) < 1 || len(kid) > 64 {
		return nil, COSEError{"kid must contain 1..64 bytes"}
	}
	protected, err := EncodeCBOR(CBORMap{coseAlg: coseEdDSA, coseKid: append([]byte(nil), kid...)})
	if err != nil {
		return nil, err
	}
	sigStructure, err := EncodeCBOR([]any{"Signature1", protected, []byte{}, payload})
	if err != nil {
		return nil, err
	}
	sig := ed25519.Sign(privateKey, sigStructure)
	return EncodeCBOR([]any{protected, CBORMap{}, payload, sig})
}

func Verify1(token []byte, keys map[string]ed25519.PublicKey) (payload, kid []byte, err error) {
	v, e := DecodeCBOR(token)
	if e != nil {
		return nil, nil, COSEError{"malformed COSE_Sign1"}
	}
	arr, ok := v.([]any)
	if !ok || len(arr) != 4 {
		return nil, nil, COSEError{"COSE_Sign1 must contain four elements"}
	}
	protected, ok1 := arr[0].([]byte)
	unprotected, ok2 := arr[1].(CBORMap)
	p, ok3 := arr[2].([]byte)
	sig, ok4 := arr[3].([]byte)
	if !ok1 || !ok2 || !ok3 || !ok4 {
		return nil, nil, COSEError{"invalid COSE_Sign1 field types"}
	}
	if len(unprotected) != 0 {
		return nil, nil, COSEError{"unprotected headers are not accepted"}
	}
	hv, e := DecodeCBOR(protected)
	if e != nil {
		return nil, nil, COSEError{"malformed protected headers"}
	}
	h, ok := hv.(CBORMap)
	if !ok || len(h) != 2 {
		return nil, nil, COSEError{"unsupported or incomplete protected headers"}
	}
	alg, aok := h[coseAlg].(int64)
	k, kok := h[coseKid].([]byte)
	if !aok || !kok || alg != coseEdDSA {
		return nil, nil, COSEError{"unsupported or incomplete protected headers"}
	}
	pub, exists := keys[string(k)]
	if !exists {
		return nil, nil, COSEError{"unknown signing key"}
	}
	ss, e := EncodeCBOR([]any{"Signature1", protected, []byte{}, p})
	if e != nil {
		return nil, nil, e
	}
	if !ed25519.Verify(pub, ss, sig) {
		return nil, nil, COSEError{"invalid signature"}
	}
	return append([]byte(nil), p...), append([]byte(nil), k...), nil
}

func EqualKID(a, b []byte) bool { return bytes.Equal(a, b) }
func WrapCOSEError(prefix string, err error) error {
	return COSEError{fmt.Sprintf("%s: %v", prefix, err)}
}
