package finality

import (
	"bytes"
	"crypto/ed25519"
	"fmt"
)

type FinalitySink struct {
	SinkID, Boundary             string
	ValidatorKeys, RequesterKeys map[string]ed25519.PublicKey
	State                        *ProtectedState
	PolicyProvider               func() PolicyState
}

func (s *FinalitySink) currentPolicy() PolicyState { return s.PolicyProvider() }
func samePredicates(v any) bool {
	a, ok := v.([]any)
	if !ok || len(a) != len(RequiredPredicates) {
		return false
	}
	for i, x := range RequiredPredicates {
		z, ok := a[i].(string)
		if !ok || z != x {
			return false
		}
	}
	return true
}
func (s *FinalitySink) validateAuthority(effect ActualEffect, bundle AuthorityBundle, now int64) (VerifiedAuthority, error) {
	var zero VerifiedAuthority
	lr, lk, e := Verify1(bundle.LAVR, s.ValidatorKeys)
	if e != nil {
		return zero, deny("invalid_authority")
	}
	cr, ck, e := Verify1(bundle.Capability, s.ValidatorKeys)
	if e != nil {
		return zero, deny("invalid_authority")
	}
	if !bytes.Equal(lk, ck) {
		return zero, deny("validator_key_mismatch")
	}
	lv, e := DecodeCBOR(lr)
	if e != nil {
		return zero, deny("invalid_authority")
	}
	cv, e := DecodeCBOR(cr)
	if e != nil {
		return zero, deny("invalid_authority")
	}
	lavr, e := asMap(lv, ints(1, 12), "lavr")
	if e != nil {
		return zero, e
	}
	cap, e := asMap(cv, ints(1, 15), "capability")
	if e != nil {
		return zero, e
	}
	ver, _ := getInt(lavr, 1, "profile_version")
	cver, _ := getInt(cap, 1, "profile_version")
	if ver != ProfileVersion || cver != ProfileVersion {
		return zero, deny("unsupported_profile_version")
	}
	if _, e = getBytes(lavr, 2, "receipt_id", 16, 32); e != nil {
		return zero, e
	}
	lc, e := getBytes(lavr, 3, "lavr_commitment", 32, 32)
	if e != nil {
		return zero, e
	}
	lrq, e := getString(lavr, 4, "lavr_requester")
	if e != nil {
		return zero, e
	}
	ln, e := getBytes(lavr, 5, "lavr_nonce", 16, 64)
	if e != nil {
		return zero, e
	}
	lp, _ := getInt(lavr, 6, "lavr_policy_version")
	ls, _ := getInt(lavr, 7, "lavr_security_epoch")
	lre, _ := getInt(lavr, 8, "lavr_revocation_epoch")
	lsi, _ := getString(lavr, 9, "lavr_sink")
	lbo, _ := getString(lavr, 10, "lavr_boundary")
	lvt, _ := getInt(lavr, 11, "lavr_validated_at")
	if !samePredicates(lavr[12]) {
		return zero, deny("lavr_predicate_mismatch")
	}
	capID, e := getBytes(cap, 2, "capability_id", 16, 32)
	if e != nil {
		return zero, e
	}
	cc, e := getBytes(cap, 3, "capability_commitment", 32, 32)
	if e != nil {
		return zero, e
	}
	ld, e := getBytes(cap, 4, "lavr_digest", 32, 32)
	if e != nil {
		return zero, e
	}
	crq, e := getString(cap, 5, "capability_requester")
	if e != nil {
		return zero, e
	}
	kt, e := getBytes(cap, 6, "requester_key_thumbprint", 32, 32)
	if e != nil {
		return zero, e
	}
	csi, _ := getString(cap, 7, "capability_sink")
	cbo, _ := getString(cap, 8, "capability_boundary")
	cn, e := getBytes(cap, 9, "capability_nonce", 16, 64)
	if e != nil {
		return zero, e
	}
	cp, _ := getInt(cap, 10, "capability_policy_version")
	cs, _ := getInt(cap, 11, "capability_security_epoch")
	cre, _ := getInt(cap, 12, "capability_revocation_epoch")
	issued, _ := getInt(cap, 13, "capability_issued_at")
	expires, _ := getInt(cap, 14, "capability_expires_at")
	count, _ := getInt(cap, 15, "permitted_effect_count")
	if count != 1 {
		return zero, deny("invalid_permitted_effect_count")
	}
	act := effect.Reconstruct()
	if e = act.Validate(); e != nil {
		return zero, e
	}
	actual, _ := act.Commitment()
	current := s.currentPolicy()
	if !eq(ld, Digest(bundle.LAVR)) || !eq(lc, cc) || !eq(cc, actual) {
		return zero, deny("authority_binding_mismatch")
	}
	if lrq != crq || crq != effect.Requester {
		return zero, deny("requester_binding_mismatch")
	}
	if !eq(ln, cn) || !eq(cn, effect.Nonce) {
		return zero, deny("nonce_binding_mismatch")
	}
	if lsi != csi || csi != effect.FinalitySink || effect.FinalitySink != s.SinkID || lbo != cbo || cbo != effect.Boundary || effect.Boundary != s.Boundary {
		return zero, deny("wrong_finality_boundary")
	}
	if lp != effect.PolicyVersion || ls != effect.SecurityEpoch || lre != effect.RevocationEpoch || cp != effect.PolicyVersion || cs != effect.SecurityEpoch || cre != effect.RevocationEpoch {
		return zero, deny("authority_epoch_mismatch")
	}
	if effect.PolicyVersion != current.Version || effect.SecurityEpoch != current.SecurityEpoch || effect.RevocationEpoch != current.RevocationEpoch {
		return zero, deny("stale_governance_state")
	}
	if !current.AllowedActions[effect.Action] || !current.AllowedDestinationApps[effect.DestinationApp] {
		return zero, deny("current_policy_denied")
	}
	if lvt != issued {
		return zero, deny("authority_time_mismatch")
	}
	if expires != effect.ExpiresAt {
		return zero, deny("authority_expiry_mismatch")
	}
	if lvt < effect.IssuedAt || lvt > effect.ExpiresAt {
		return zero, deny("invalid_validation_time")
	}
	if now < issued {
		return zero, deny("authority_not_yet_valid")
	}
	if now > expires {
		return zero, deny("authority_expired")
	}
	if e = s.State.AssertIssued(capID, act, issued); e != nil {
		return zero, e
	}
	if s.State.IsRevoked(effect.Requester, cre) {
		return zero, deny("authority_revoked")
	}
	_ = kt
	return VerifiedAuthority{lavr, cap, cloneBytes(capID), cloneBytes(actual), cloneBytes(ck)}, nil
}
func (s *FinalitySink) IssueChallenge(effect ActualEffect, bundle AuthorityBundle, channel []byte, now, ttl int64) ([]byte, error) {
	if len(channel) < 16 {
		return nil, deny("missing_protected_channel_binding")
	}
	if ttl < 1 || ttl > MaxChallengeTTL {
		return nil, deny("invalid_challenge_ttl")
	}
	v, e := s.validateAuthority(effect, bundle, now)
	if e != nil {
		return nil, e
	}
	id, e := randomBytes(16)
	if e != nil {
		return nil, e
	}
	nonce, e := randomBytes(32)
	if e != nil {
		return nil, e
	}
	token := CBORMap{1: ProfileVersion, 2: id, 3: nonce, 4: Digest(bundle.Capability), 5: v.ActualCommitment, 6: s.SinkID, 7: s.Boundary, 8: Digest(channel), 9: now, 10: now + ttl, 11: v.CapID}
	if e = s.State.RecordChallenge(token); e != nil {
		return nil, e
	}
	return EncodeCBOR(token)
}
func (s *FinalitySink) Finalize(effect ActualEffect, bundle AuthorityBundle, challengeToken, presentation, channel []byte, now int64) (string, error) {
	if len(channel) < 16 {
		return "", deny("missing_protected_channel_binding")
	}
	v, e := s.validateAuthority(effect, bundle, now)
	if e != nil {
		return "", e
	}
	cv, e := DecodeCBOR(challengeToken)
	if e != nil {
		return "", deny("invalid_challenge")
	}
	ch, e := asMap(cv, ints(1, 11), "challenge")
	if e != nil {
		return "", e
	}
	ver, _ := getInt(ch, 1, "challenge_version")
	if ver != ProfileVersion {
		return "", deny("unsupported_challenge_version")
	}
	id, e := getBytes(ch, 2, "challenge_id", 16, 32)
	if e != nil {
		return "", e
	}
	nonce, e := getBytes(ch, 3, "challenge_nonce", 32, 32)
	if e != nil {
		return "", e
	}
	cd, e := getBytes(ch, 4, "challenge_capability_digest", 32, 32)
	if e != nil {
		return "", e
	}
	ec, e := getBytes(ch, 5, "challenge_effect_commitment", 32, 32)
	if e != nil {
		return "", e
	}
	si, _ := getString(ch, 6, "challenge_sink")
	bo, _ := getString(ch, 7, "challenge_boundary")
	bd, e := getBytes(ch, 8, "channel_binding_digest", 32, 32)
	if e != nil {
		return "", e
	}
	issued, _ := getInt(ch, 9, "challenge_issued_at")
	expires, _ := getInt(ch, 10, "challenge_expires_at")
	cid, e := getBytes(ch, 11, "challenge_capability_id", 16, 32)
	if e != nil {
		return "", e
	}
	if expires <= issued || expires-issued > MaxChallengeTTL {
		return "", deny("invalid_challenge_window")
	}
	if now < issued {
		return "", deny("challenge_not_yet_valid")
	}
	if now > expires {
		return "", deny("challenge_expired")
	}
	if !eq(cd, Digest(bundle.Capability)) || !eq(ec, v.ActualCommitment) || si != s.SinkID || bo != s.Boundary || !eq(bd, Digest(channel)) || !eq(cid, v.CapID) {
		return "", deny("challenge_context_mismatch")
	}
	pr, pk, e := Verify1(presentation, s.RequesterKeys)
	if e != nil {
		return "", deny("invalid_proof_of_possession")
	}
	pv, e := DecodeCBOR(pr)
	if e != nil {
		return "", deny("invalid_proof_of_possession")
	}
	pop, e := asMap(pv, ints(1, 10), "presentation")
	if e != nil {
		return "", e
	}
	pver, _ := getInt(pop, 1, "presentation_version")
	if pver != ProfileVersion {
		return "", deny("unsupported_presentation_version")
	}
	pub, ok := s.RequesterKeys[string(pk)]
	if !ok {
		return "", deny("requester_key_mismatch")
	}
	capThumb, _ := getBytes(v.Capability, 6, "requester_key_thumbprint", 32, 32)
	if !eq(KeyThumbprint(pub), capThumb) {
		return "", deny("requester_key_mismatch")
	}
	exact := CBORMap{1: ProfileVersion, 2: Digest(bundle.Capability), 3: v.ActualCommitment, 4: effect.ActID, 5: effect.Nonce, 6: id, 7: nonce, 8: s.SinkID, 9: s.Boundary, 10: Digest(channel)}
	a, _ := EncodeCBOR(pop)
	b, _ := EncodeCBOR(exact)
	if !eq(a, b) {
		return "", deny("proof_of_possession_mismatch")
	}
	cre, _ := getInt(v.Capability, 12, "capability_revocation_epoch")
	if s.State.IsRevoked(effect.Requester, cre) {
		return "", deny("authority_revoked")
	}
	current := s.currentPolicy()
	if e = s.State.Finalize(v.CapID, ch, effect, current, now); e != nil {
		return "", e
	}
	return "EFFECT_COMMITTED", nil
}
func (s *FinalitySink) String() string {
	return fmt.Sprintf("FinalitySink(%s,%s)", s.SinkID, s.Boundary)
}
