package finality

import (
	"crypto/ed25519"
	"crypto/rand"
	"errors"
	"sync"
	"testing"
)

type fixture struct {
	validatorPriv ed25519.PrivateKey
	validatorPub  ed25519.PublicKey
	requesterPriv ed25519.PrivateKey
	requesterPub  ed25519.PublicKey
	validatorKID  []byte
	requesterKID  []byte
	state         *ProtectedState
	policy        *PolicyState
	validator     *ProtectedValidator
	sink          *FinalitySink
	act           CandidateAct
	effect        ActualEffect
	channel       []byte
	now           int64
}

func newFixture(t *testing.T) *fixture {
	t.Helper()
	vpub, vpriv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	rpub, rpriv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	state := NewProtectedState()
	policy := &PolicyState{Version: 7, SecurityEpoch: 11, RevocationEpoch: 3, AllowedActions: map[string]bool{"message.send": true, "file.export": true, "app.dispatch": true}, AllowedDestinationApps: map[string]bool{"system.messages": true, "files": true, "launcher": true}}
	now := int64(1_800_000_000)
	nonce := make([]byte, 16)
	for i := range nonce {
		nonce[i] = byte(i + 1)
	}
	intent := Digest([]byte("user-confirmed:send-to-alice"))
	resource := []byte("hello from independent Go implementation")
	effect := ActualEffect{Requester: "assistant.example", Action: "message.send", Resource: resource, Destination: "alice@example.com", DestinationApp: "system.messages", FinalitySink: "urn:device:sink:messages", Boundary: "messages-send-boundary", SessionID: "session-123", UserIntentDigest: intent, PolicyVersion: 7, SecurityEpoch: 11, RevocationEpoch: 3, Nonce: nonce, IssuedAt: now - 1, ExpiresAt: now + 30, ActID: "act-001"}
	act := effect.Reconstruct()
	vkid := []byte("validator-1")
	rkid := []byte("requester-1")
	validator := &ProtectedValidator{Key: vpriv, KID: vkid, RequesterKeys: map[string]ed25519.PublicKey{"assistant.example": rpub}, State: state, Policy: *policy}
	sink := &FinalitySink{SinkID: effect.FinalitySink, Boundary: effect.Boundary, ValidatorKeys: map[string]ed25519.PublicKey{string(vkid): vpub}, RequesterKeys: map[string]ed25519.PublicKey{string(rkid): rpub}, State: state, PolicyProvider: func() PolicyState { return *policy }}
	return &fixture{vpriv, vpub, rpriv, rpub, vkid, rkid, state, policy, validator, sink, act, effect, []byte("protected-channel-binding-001"), now}
}
func denialCode(err error) string {
	var d Denied
	if errors.As(err, &d) {
		return d.Code
	}
	return ""
}
func authorityAndChallenge(t *testing.T, f *fixture) (AuthorityBundle, []byte) {
	t.Helper()
	b, err := f.validator.IssueAuthority(f.act, true, f.now)
	if err != nil {
		t.Fatal(err)
	}
	ch, err := f.sink.IssueChallenge(f.effect, b, f.channel, f.now, 5)
	if err != nil {
		t.Fatal(err)
	}
	return b, ch
}

func TestHappyPath(t *testing.T) {
	f := newFixture(t)
	b, ch := authorityAndChallenge(t, f)
	p, err := CreatePresentation(b.Capability, f.effect, ch, f.channel, f.requesterPriv, f.requesterKID)
	if err != nil {
		t.Fatal(err)
	}
	res, err := f.sink.Finalize(f.effect, b, ch, p, f.channel, f.now)
	if err != nil {
		t.Fatal(err)
	}
	if res != "EFFECT_COMMITTED" || f.state.EffectCount() != 1 {
		t.Fatalf("unexpected result %q count=%d", res, f.state.EffectCount())
	}
}
func TestCapabilityReplayRejected(t *testing.T) {
	f := newFixture(t)
	b, ch := authorityAndChallenge(t, f)
	p, _ := CreatePresentation(b.Capability, f.effect, ch, f.channel, f.requesterPriv, f.requesterKID)
	if _, e := f.sink.Finalize(f.effect, b, ch, p, f.channel, f.now); e != nil {
		t.Fatal(e)
	}
	if _, e := f.sink.Finalize(f.effect, b, ch, p, f.channel, f.now); denialCode(e) != "authority_state_mismatch" {
		t.Fatalf("got %v", e)
	}
}
func TestWrongDestinationRejected(t *testing.T) {
	f := newFixture(t)
	b, _ := f.validator.IssueAuthority(f.act, true, f.now)
	bad := f.effect
	bad.Destination = "mallory@example.com"
	if _, e := f.sink.IssueChallenge(bad, b, f.channel, f.now, 5); denialCode(e) != "authority_binding_mismatch" {
		t.Fatalf("got %v", e)
	}
}
func TestWrongResourceRejected(t *testing.T) {
	f := newFixture(t)
	b, _ := f.validator.IssueAuthority(f.act, true, f.now)
	bad := f.effect
	bad.Resource = []byte("substituted")
	if _, e := f.sink.IssueChallenge(bad, b, f.channel, f.now, 5); denialCode(e) != "authority_binding_mismatch" {
		t.Fatalf("got %v", e)
	}
}
func TestWrongSinkRejected(t *testing.T) {
	f := newFixture(t)
	b, _ := f.validator.IssueAuthority(f.act, true, f.now)
	bad := f.effect
	bad.FinalitySink = "urn:wrong"
	if _, e := f.sink.IssueChallenge(bad, b, f.channel, f.now, 5); denialCode(e) != "authority_binding_mismatch" {
		t.Fatalf("got %v", e)
	}
}
func TestChannelBindingMismatchRejected(t *testing.T) {
	f := newFixture(t)
	b, ch := authorityAndChallenge(t, f)
	other := []byte("different-protected-channel")
	p, _ := CreatePresentation(b.Capability, f.effect, ch, other, f.requesterPriv, f.requesterKID)
	if _, e := f.sink.Finalize(f.effect, b, ch, p, other, f.now); denialCode(e) != "challenge_context_mismatch" {
		t.Fatalf("got %v", e)
	}
}
func TestPresentationCreatedForOtherChallengeRejected(t *testing.T) {
	f := newFixture(t)
	b, ch1 := authorityAndChallenge(t, f)
	ch2, err := f.sink.IssueChallenge(f.effect, b, f.channel, f.now, 5)
	if err != nil {
		t.Fatal(err)
	}
	p, _ := CreatePresentation(b.Capability, f.effect, ch1, f.channel, f.requesterPriv, f.requesterKID)
	if _, e := f.sink.Finalize(f.effect, b, ch2, p, f.channel, f.now); denialCode(e) != "proof_of_possession_mismatch" {
		t.Fatalf("got %v", e)
	}
}
func TestChallengeExpiredRejected(t *testing.T) {
	f := newFixture(t)
	b, ch := authorityAndChallenge(t, f)
	p, _ := CreatePresentation(b.Capability, f.effect, ch, f.channel, f.requesterPriv, f.requesterKID)
	if _, e := f.sink.Finalize(f.effect, b, ch, p, f.channel, f.now+6); denialCode(e) != "challenge_expired" {
		t.Fatalf("got %v", e)
	}
}
func TestRevocationAfterChallengeRejected(t *testing.T) {
	f := newFixture(t)
	b, ch := authorityAndChallenge(t, f)
	p, _ := CreatePresentation(b.Capability, f.effect, ch, f.channel, f.requesterPriv, f.requesterKID)
	_ = f.state.Revoke(f.effect.Requester, f.policy.RevocationEpoch)
	if _, e := f.sink.Finalize(f.effect, b, ch, p, f.channel, f.now); denialCode(e) != "authority_revoked" {
		t.Fatalf("got %v", e)
	}
}
func TestPolicyEpochChangeRejected(t *testing.T) {
	f := newFixture(t)
	b, ch := authorityAndChallenge(t, f)
	p, _ := CreatePresentation(b.Capability, f.effect, ch, f.channel, f.requesterPriv, f.requesterKID)
	f.policy.SecurityEpoch++
	if _, e := f.sink.Finalize(f.effect, b, ch, p, f.channel, f.now); denialCode(e) != "stale_governance_state" {
		t.Fatalf("got %v", e)
	}
}
func TestUserIntentRequired(t *testing.T) {
	f := newFixture(t)
	if _, e := f.validator.IssueAuthority(f.act, false, f.now); denialCode(e) != "user_intent_required" {
		t.Fatalf("got %v", e)
	}
}
func TestFutureCandidateRejected(t *testing.T) {
	f := newFixture(t)
	f.act.IssuedAt = f.now + 10
	f.act.ExpiresAt = f.now + 20
	if _, e := f.validator.IssueAuthority(f.act, true, f.now); denialCode(e) != "candidate_not_yet_valid" {
		t.Fatalf("got %v", e)
	}
}
func TestExpiredCandidateRejected(t *testing.T) {
	f := newFixture(t)
	f.act.IssuedAt = f.now - 20
	f.act.ExpiresAt = f.now - 1
	if _, e := f.validator.IssueAuthority(f.act, true, f.now); denialCode(e) != "candidate_expired" {
		t.Fatalf("got %v", e)
	}
}
func TestUnknownRequesterRejected(t *testing.T) {
	f := newFixture(t)
	f.act.Requester = "unknown"
	if _, e := f.validator.IssueAuthority(f.act, true, f.now); denialCode(e) != "unknown_requester" {
		t.Fatalf("got %v", e)
	}
}
func TestWrongRequesterKeyRejected(t *testing.T) {
	f := newFixture(t)
	b, ch := authorityAndChallenge(t, f)
	_, wrong, _ := ed25519.GenerateKey(rand.Reader)
	p, _ := CreatePresentation(b.Capability, f.effect, ch, f.channel, wrong, []byte("unknown-kid"))
	if _, e := f.sink.Finalize(f.effect, b, ch, p, f.channel, f.now); denialCode(e) != "invalid_proof_of_possession" {
		t.Fatalf("got %v", e)
	}
}
func TestChallengeTTLBounds(t *testing.T) {
	f := newFixture(t)
	b, _ := f.validator.IssueAuthority(f.act, true, f.now)
	if _, e := f.sink.IssueChallenge(f.effect, b, f.channel, f.now, 0); denialCode(e) != "invalid_challenge_ttl" {
		t.Fatalf("ttl0: %v", e)
	}
	if _, e := f.sink.IssueChallenge(f.effect, b, f.channel, f.now, 31); denialCode(e) != "invalid_challenge_ttl" {
		t.Fatalf("ttl31: %v", e)
	}
}
func TestMissingChannelBindingRejected(t *testing.T) {
	f := newFixture(t)
	b, _ := f.validator.IssueAuthority(f.act, true, f.now)
	if _, e := f.sink.IssueChallenge(f.effect, b, []byte("short"), f.now, 5); denialCode(e) != "missing_protected_channel_binding" {
		t.Fatalf("got %v", e)
	}
}
func TestConcurrentFinalizeOnlyOneCommits(t *testing.T) {
	f := newFixture(t)
	b, ch := authorityAndChallenge(t, f)
	p, _ := CreatePresentation(b.Capability, f.effect, ch, f.channel, f.requesterPriv, f.requesterKID)
	var wg sync.WaitGroup
	wg.Add(2)
	errs := make(chan error, 2)
	for i := 0; i < 2; i++ {
		go func() { defer wg.Done(); _, e := f.sink.Finalize(f.effect, b, ch, p, f.channel, f.now); errs <- e }()
	}
	wg.Wait()
	close(errs)
	ok, fail := 0, 0
	for e := range errs {
		if e == nil {
			ok++
		} else {
			fail++
		}
	}
	if ok != 1 || fail != 1 || f.state.EffectCount() != 1 {
		t.Fatalf("ok=%d fail=%d effects=%d", ok, fail, f.state.EffectCount())
	}
}
func TestNonceReuseRejected(t *testing.T) {
	f := newFixture(t)
	if _, e := f.validator.IssueAuthority(f.act, true, f.now); e != nil {
		t.Fatal(e)
	}
	second := f.act
	second.ActID = "act-002"
	if _, e := f.validator.IssueAuthority(second, true, f.now); denialCode(e) != "nonce_or_act_reuse" {
		t.Fatalf("got %v", e)
	}
}
func TestActIDReuseRejected(t *testing.T) {
	f := newFixture(t)
	if _, e := f.validator.IssueAuthority(f.act, true, f.now); e != nil {
		t.Fatal(e)
	}
	second := f.act
	second.Nonce = []byte("another-nonce-000")
	if _, e := f.validator.IssueAuthority(second, true, f.now); denialCode(e) != "nonce_or_act_reuse" {
		t.Fatalf("got %v", e)
	}
}

func resignToken(t *testing.T, token []byte, key ed25519.PrivateKey, kid []byte, mutate func(CBORMap)) []byte {
	t.Helper()
	payload, _, err := Verify1(token, map[string]ed25519.PublicKey{string(kid): key.Public().(ed25519.PublicKey)})
	if err != nil {
		t.Fatal(err)
	}
	v, err := DecodeCBOR(payload)
	if err != nil {
		t.Fatal(err)
	}
	m := v.(CBORMap)
	mutate(m)
	raw, err := EncodeCBOR(m)
	if err != nil {
		t.Fatal(err)
	}
	out, err := Sign1(raw, key, kid)
	if err != nil {
		t.Fatal(err)
	}
	return out
}

func TestLAVRExtraFieldRejected(t *testing.T) {
	f := newFixture(t)
	b, err := f.validator.IssueAuthority(f.act, true, f.now)
	if err != nil {
		t.Fatal(err)
	}
	b.LAVR = resignToken(t, b.LAVR, f.validatorPriv, f.validatorKID, func(m CBORMap) { m[99] = "unexpected" })
	if _, e := f.sink.IssueChallenge(f.effect, b, f.channel, f.now, 5); denialCode(e) != "invalid_lavr_schema" {
		t.Fatalf("got %v", e)
	}
}
func TestCapabilityMissingFieldRejected(t *testing.T) {
	f := newFixture(t)
	b, err := f.validator.IssueAuthority(f.act, true, f.now)
	if err != nil {
		t.Fatal(err)
	}
	b.Capability = resignToken(t, b.Capability, f.validatorPriv, f.validatorKID, func(m CBORMap) { delete(m, 8) })
	if _, e := f.sink.IssueChallenge(f.effect, b, f.channel, f.now, 5); denialCode(e) != "invalid_capability_schema" {
		t.Fatalf("got %v", e)
	}
}
func TestPermittedEffectCountRejected(t *testing.T) {
	f := newFixture(t)
	b, err := f.validator.IssueAuthority(f.act, true, f.now)
	if err != nil {
		t.Fatal(err)
	}
	b.Capability = resignToken(t, b.Capability, f.validatorPriv, f.validatorKID, func(m CBORMap) { m[15] = int64(2) })
	if _, e := f.sink.IssueChallenge(f.effect, b, f.channel, f.now, 5); denialCode(e) != "invalid_permitted_effect_count" {
		t.Fatalf("got %v", e)
	}
}
func TestLAVRPredicateMutationRejected(t *testing.T) {
	f := newFixture(t)
	b, err := f.validator.IssueAuthority(f.act, true, f.now)
	if err != nil {
		t.Fatal(err)
	}
	b.LAVR = resignToken(t, b.LAVR, f.validatorPriv, f.validatorKID, func(m CBORMap) { m[12] = []any{"destination", "policy"} })
	if _, e := f.sink.IssueChallenge(f.effect, b, f.channel, f.now, 5); denialCode(e) != "lavr_predicate_mismatch" {
		t.Fatalf("got %v", e)
	}
}
func TestCapabilityRequesterMutationRejected(t *testing.T) {
	f := newFixture(t)
	b, err := f.validator.IssueAuthority(f.act, true, f.now)
	if err != nil {
		t.Fatal(err)
	}
	b.Capability = resignToken(t, b.Capability, f.validatorPriv, f.validatorKID, func(m CBORMap) { m[5] = "other.requester" })
	if _, e := f.sink.IssueChallenge(f.effect, b, f.channel, f.now, 5); denialCode(e) != "requester_binding_mismatch" {
		t.Fatalf("got %v", e)
	}
}
func TestCapabilitySinkMutationRejected(t *testing.T) {
	f := newFixture(t)
	b, err := f.validator.IssueAuthority(f.act, true, f.now)
	if err != nil {
		t.Fatal(err)
	}
	b.Capability = resignToken(t, b.Capability, f.validatorPriv, f.validatorKID, func(m CBORMap) { m[7] = "urn:wrong:sink" })
	if _, e := f.sink.IssueChallenge(f.effect, b, f.channel, f.now, 5); denialCode(e) != "wrong_finality_boundary" {
		t.Fatalf("got %v", e)
	}
}
func TestCapabilityExpiryMutationRejected(t *testing.T) {
	f := newFixture(t)
	b, err := f.validator.IssueAuthority(f.act, true, f.now)
	if err != nil {
		t.Fatal(err)
	}
	b.Capability = resignToken(t, b.Capability, f.validatorPriv, f.validatorKID, func(m CBORMap) { m[14] = f.effect.ExpiresAt + 1 })
	if _, e := f.sink.IssueChallenge(f.effect, b, f.channel, f.now, 5); denialCode(e) != "authority_expiry_mismatch" {
		t.Fatalf("got %v", e)
	}
}
func TestChallengeExtraFieldRejected(t *testing.T) {
	f := newFixture(t)
	b, ch := authorityAndChallenge(t, f)
	v, err := DecodeCBOR(ch)
	if err != nil {
		t.Fatal(err)
	}
	m := v.(CBORMap)
	m[99] = "unexpected"
	bad, err := EncodeCBOR(m)
	if err != nil {
		t.Fatal(err)
	}
	p, _ := CreatePresentation(b.Capability, f.effect, ch, f.channel, f.requesterPriv, f.requesterKID)
	if _, e := f.sink.Finalize(f.effect, b, bad, p, f.channel, f.now); denialCode(e) != "invalid_challenge_schema" {
		t.Fatalf("got %v", e)
	}
}
func TestPresentationExtraFieldRejected(t *testing.T) {
	f := newFixture(t)
	b, ch := authorityAndChallenge(t, f)
	p, _ := CreatePresentation(b.Capability, f.effect, ch, f.channel, f.requesterPriv, f.requesterKID)
	p = resignToken(t, p, f.requesterPriv, f.requesterKID, func(m CBORMap) { m[99] = "unexpected" })
	if _, e := f.sink.Finalize(f.effect, b, ch, p, f.channel, f.now); denialCode(e) != "invalid_presentation_schema" {
		t.Fatalf("got %v", e)
	}
}
func TestValidatorKeyMismatchRejected(t *testing.T) {
	f := newFixture(t)
	b, err := f.validator.IssueAuthority(f.act, true, f.now)
	if err != nil {
		t.Fatal(err)
	}
	pub2, priv2, _ := ed25519.GenerateKey(rand.Reader)
	kid2 := []byte("validator-2")
	f.sink.ValidatorKeys[string(kid2)] = pub2
	payload, _, err := Verify1(b.Capability, map[string]ed25519.PublicKey{string(f.validatorKID): f.validatorPub})
	if err != nil {
		t.Fatal(err)
	}
	b.Capability, err = Sign1(payload, priv2, kid2)
	if err != nil {
		t.Fatal(err)
	}
	if _, e := f.sink.IssueChallenge(f.effect, b, f.channel, f.now, 5); denialCode(e) != "validator_key_mismatch" {
		t.Fatalf("got %v", e)
	}
}
