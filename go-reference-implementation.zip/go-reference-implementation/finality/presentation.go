package finality

import "crypto/ed25519"

func CreatePresentation(capability []byte, effect ActualEffect, challengeToken, channel []byte, requesterKey ed25519.PrivateKey, kid []byte) ([]byte, error) {
	if len(channel) < 16 {
		return nil, deny("missing_protected_channel_binding")
	}
	cv, e := DecodeCBOR(challengeToken)
	if e != nil {
		return nil, deny("invalid_challenge")
	}
	ch, e := asMap(cv, ints(1, 11), "challenge")
	if e != nil {
		return nil, e
	}
	id, e := getBytes(ch, 2, "challenge_id", 16, 32)
	if e != nil {
		return nil, e
	}
	nonce, e := getBytes(ch, 3, "challenge_nonce", 32, 32)
	if e != nil {
		return nil, e
	}
	actual, e := effect.Reconstruct().Commitment()
	if e != nil {
		return nil, e
	}
	payload, e := EncodeCBOR(CBORMap{1: ProfileVersion, 2: Digest(capability), 3: actual, 4: effect.ActID, 5: effect.Nonce, 6: id, 7: nonce, 8: effect.FinalitySink, 9: effect.Boundary, 10: Digest(channel)})
	if e != nil {
		return nil, e
	}
	return Sign1(payload, requesterKey, kid)
}
