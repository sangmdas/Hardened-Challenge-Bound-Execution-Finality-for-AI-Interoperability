package finality

import (
	"encoding/hex"
	"sync"
)

type issuedRecord struct {
	ActID           string
	Nonce           []byte
	Requester       string
	Commitment      []byte
	Issued, Expires int64
	State           string
}
type challengeRecord struct {
	Nonce, CapID, CapabilityDigest, EffectCommitment []byte
	SinkID, Boundary                                 string
	ChannelBindingDigest                             []byte
	Issued, Expires                                  int64
	State                                            string
}
type EffectRecord struct {
	ActID, Action, Destination string
	Resource                   []byte
	CommittedAt                int64
}

type ProtectedState struct {
	mu                  sync.Mutex
	issued              map[string]issuedRecord
	nonceIndex          map[string]bool
	actIndex            map[string]bool
	challenges          map[string]challengeRecord
	challengeNonceIndex map[string]bool
	revoked             map[string]int64
	effects             map[string]EffectRecord
}

func NewProtectedState() *ProtectedState {
	return &ProtectedState{issued: map[string]issuedRecord{}, nonceIndex: map[string]bool{}, actIndex: map[string]bool{}, challenges: map[string]challengeRecord{}, challengeNonceIndex: map[string]bool{}, revoked: map[string]int64{}, effects: map[string]EffectRecord{}}
}
func key(b []byte) string { return hex.EncodeToString(b) }
func (s *ProtectedState) RecordIssued(capID []byte, act CandidateAct, issuedAt int64) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.nonceIndex[key(act.Nonce)] || s.actIndex[act.ActID] {
		return deny("nonce_or_act_reuse")
	}
	c, _ := act.Commitment()
	s.issued[key(capID)] = issuedRecord{act.ActID, cloneBytes(act.Nonce), act.Requester, c, issuedAt, act.ExpiresAt, "ISSUED"}
	s.nonceIndex[key(act.Nonce)] = true
	s.actIndex[act.ActID] = true
	return nil
}
func (s *ProtectedState) RecordChallenge(token CBORMap) error {
	id, _ := token[2].([]byte)
	nonce, _ := token[3].([]byte)
	capID, _ := token[11].([]byte)
	s.mu.Lock()
	defer s.mu.Unlock()
	if _, ok := s.challenges[key(id)]; ok || s.challengeNonceIndex[key(nonce)] {
		return deny("challenge_reuse")
	}
	s.challenges[key(id)] = challengeRecord{cloneBytes(nonce), cloneBytes(capID), cloneBytes(token[4].([]byte)), cloneBytes(token[5].([]byte)), token[6].(string), token[7].(string), cloneBytes(token[8].([]byte)), token[9].(int64), token[10].(int64), "ISSUED"}
	s.challengeNonceIndex[key(nonce)] = true
	return nil
}
func (s *ProtectedState) Revoke(subject string, epoch int64) error {
	if !validString(subject) || epoch < 0 {
		return deny("invalid_revocation")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if old, ok := s.revoked[subject]; !ok || epoch > old {
		s.revoked[subject] = epoch
	}
	return nil
}
func (s *ProtectedState) IsRevoked(subject string, capabilityEpoch int64) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	e, ok := s.revoked[subject]
	return ok && e >= capabilityEpoch
}
func (s *ProtectedState) AssertIssued(capID []byte, act CandidateAct, capIssued int64) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	r, ok := s.issued[key(capID)]
	if !ok {
		return deny("authority_unknown")
	}
	c, _ := act.Commitment()
	if r.ActID != act.ActID || !eq(r.Nonce, act.Nonce) || r.Requester != act.Requester || !eq(r.Commitment, c) || r.Issued != capIssued || r.Expires != act.ExpiresAt || r.State != "ISSUED" {
		return deny("authority_state_mismatch")
	}
	return nil
}
func (s *ProtectedState) Finalize(capID []byte, challenge CBORMap, effect ActualEffect, current PolicyState, now int64) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	cap, ok := s.issued[key(capID)]
	if !ok || cap.State != "ISSUED" {
		return deny("authority_consumed_or_unknown")
	}
	ci := challenge[9].(int64)
	ce := challenge[10].(int64)
	if now < ci {
		return deny("challenge_not_yet_valid")
	}
	if now > ce {
		return deny("challenge_expired")
	}
	ch, ok := s.challenges[key(challenge[2].([]byte))]
	if !ok || ch.State != "ISSUED" {
		return deny("challenge_consumed_or_mismatch")
	}
	if !eq(ch.Nonce, challenge[3].([]byte)) || !eq(ch.CapID, challenge[11].([]byte)) || !eq(ch.CapabilityDigest, challenge[4].([]byte)) || !eq(ch.EffectCommitment, challenge[5].([]byte)) || ch.SinkID != challenge[6].(string) || ch.Boundary != challenge[7].(string) || !eq(ch.ChannelBindingDigest, challenge[8].([]byte)) || ch.Issued != ci || ch.Expires != ce {
		return deny("challenge_consumed_or_mismatch")
	}
	if now > cap.Expires {
		return deny("authority_expired")
	}
	if epoch, ok := s.revoked[cap.Requester]; ok && epoch >= current.RevocationEpoch {
		return deny("authority_revoked")
	}
	if effect.PolicyVersion != current.Version || effect.SecurityEpoch != current.SecurityEpoch || effect.RevocationEpoch != current.RevocationEpoch {
		return deny("stale_governance_state")
	}
	if _, exists := s.effects[effect.ActID]; exists {
		return deny("effect_already_committed")
	}
	cap.State = "CONSUMED"
	s.issued[key(capID)] = cap
	ch.State = "CONSUMED"
	s.challenges[key(challenge[2].([]byte))] = ch
	s.effects[effect.ActID] = EffectRecord{effect.ActID, effect.Action, effect.Destination, cloneBytes(effect.Resource), now}
	return nil
}
func (s *ProtectedState) EffectCount() int { s.mu.Lock(); defer s.mu.Unlock(); return len(s.effects) }
