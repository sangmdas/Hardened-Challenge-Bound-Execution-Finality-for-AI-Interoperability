package finality

import (
	"bytes"
	"encoding/binary"
	"errors"
	"fmt"
	"unicode/utf8"
)

// CBORMap is the strict integer-keyed map profile used by this reference implementation.
// The encoder follows deterministic CBOR map ordering by encoded-key length and then lexical bytes.
type CBORMap map[int64]any

type CBORError struct{ Msg string }

func (e CBORError) Error() string { return e.Msg }

func cborHead(major byte, value uint64) ([]byte, error) {
	p := major << 5
	switch {
	case value < 24:
		return []byte{p | byte(value)}, nil
	case value <= 0xff:
		return []byte{p | 24, byte(value)}, nil
	case value <= 0xffff:
		out := []byte{p | 25, 0, 0}
		binary.BigEndian.PutUint16(out[1:], uint16(value))
		return out, nil
	case value <= 0xffffffff:
		out := make([]byte, 5)
		out[0] = p | 26
		binary.BigEndian.PutUint32(out[1:], uint32(value))
		return out, nil
	default:
		out := make([]byte, 9)
		out[0] = p | 27
		binary.BigEndian.PutUint64(out[1:], value)
		return out, nil
	}
}

func EncodeCBOR(v any) ([]byte, error) {
	var b bytes.Buffer
	if err := encodeCBOR(&b, v); err != nil {
		return nil, err
	}
	return b.Bytes(), nil
}

func encodeCBOR(b *bytes.Buffer, v any) error {
	switch x := v.(type) {
	case nil:
		b.WriteByte(0xf6)
		return nil
	case bool:
		if x {
			b.WriteByte(0xf5)
		} else {
			b.WriteByte(0xf4)
		}
		return nil
	case int:
		return encodeCBOR(b, int64(x))
	case int64:
		if x >= 0 {
			h, _ := cborHead(0, uint64(x))
			b.Write(h)
			return nil
		}
		h, _ := cborHead(1, uint64(-1-x))
		b.Write(h)
		return nil
	case uint64:
		if x > uint64(^uint64(0)>>1) {
			return CBORError{"integer outside signed reference range"}
		}
		h, _ := cborHead(0, x)
		b.Write(h)
		return nil
	case []byte:
		h, _ := cborHead(2, uint64(len(x)))
		b.Write(h)
		b.Write(x)
		return nil
	case string:
		raw := []byte(x)
		h, _ := cborHead(3, uint64(len(raw)))
		b.Write(h)
		b.Write(raw)
		return nil
	case []any:
		h, _ := cborHead(4, uint64(len(x)))
		b.Write(h)
		for _, item := range x {
			if err := encodeCBOR(b, item); err != nil {
				return err
			}
		}
		return nil
	case []string:
		arr := make([]any, len(x))
		for i := range x {
			arr[i] = x[i]
		}
		return encodeCBOR(b, arr)
	case CBORMap:
		type kv struct{ k, v []byte }
		pairs := make([]kv, 0, len(x))
		for key, val := range x {
			ek, err := EncodeCBOR(key)
			if err != nil {
				return err
			}
			ev, err := EncodeCBOR(val)
			if err != nil {
				return err
			}
			pairs = append(pairs, kv{ek, ev})
		}
		for i := 0; i < len(pairs); i++ {
			for j := i + 1; j < len(pairs); j++ {
				if len(pairs[j].k) < len(pairs[i].k) || (len(pairs[j].k) == len(pairs[i].k) && bytes.Compare(pairs[j].k, pairs[i].k) < 0) {
					pairs[i], pairs[j] = pairs[j], pairs[i]
				}
			}
		}
		h, _ := cborHead(5, uint64(len(pairs)))
		b.Write(h)
		for _, p := range pairs {
			b.Write(p.k)
			b.Write(p.v)
		}
		return nil
	default:
		return CBORError{fmt.Sprintf("unsupported type %T", v)}
	}
}

type cborDecoder struct {
	data []byte
	pos  int
}

func (d *cborDecoder) take(n int) ([]byte, error) {
	if n < 0 || d.pos+n > len(d.data) {
		return nil, CBORError{"truncated CBOR"}
	}
	out := d.data[d.pos : d.pos+n]
	d.pos += n
	return out, nil
}
func (d *cborDecoder) argument(add byte) (uint64, error) {
	if add < 24 {
		return uint64(add), nil
	}
	var n int
	var min uint64
	switch add {
	case 24:
		n, min = 1, 24
	case 25:
		n, min = 2, 256
	case 26:
		n, min = 4, 65536
	case 27:
		n, min = 8, 4294967296
	default:
		return 0, CBORError{"indefinite or reserved encoding rejected"}
	}
	raw, err := d.take(n)
	if err != nil {
		return 0, err
	}
	var v uint64
	switch n {
	case 1:
		v = uint64(raw[0])
	case 2:
		v = uint64(binary.BigEndian.Uint16(raw))
	case 4:
		v = uint64(binary.BigEndian.Uint32(raw))
	case 8:
		v = binary.BigEndian.Uint64(raw)
	}
	if v < min {
		return 0, CBORError{"non-minimal integer encoding"}
	}
	return v, nil
}
func (d *cborDecoder) item() (any, error) {
	raw, err := d.take(1)
	if err != nil {
		return nil, err
	}
	initial := raw[0]
	major, add := initial>>5, initial&31
	if major == 7 {
		switch add {
		case 20:
			return false, nil
		case 21:
			return true, nil
		case 22:
			return nil, nil
		default:
			return nil, CBORError{"unsupported simple value"}
		}
	}
	arg, err := d.argument(add)
	if err != nil {
		return nil, err
	}
	if arg > uint64(^uint(0)>>1) {
		return nil, CBORError{"length too large"}
	}
	switch major {
	case 0:
		if arg > uint64(^uint64(0)>>1) {
			return nil, CBORError{"integer outside signed reference range"}
		}
		return int64(arg), nil
	case 1:
		if arg > uint64(^uint64(0)>>1) {
			return nil, CBORError{"integer outside signed reference range"}
		}
		return -1 - int64(arg), nil
	case 2:
		x, err := d.take(int(arg))
		if err != nil {
			return nil, err
		}
		return append([]byte(nil), x...), nil
	case 3:
		x, err := d.take(int(arg))
		if err != nil {
			return nil, err
		}
		if !utf8.Valid(x) {
			return nil, CBORError{"invalid UTF-8"}
		}
		return string(x), nil
	case 4:
		a := make([]any, 0, int(arg))
		for i := 0; i < int(arg); i++ {
			x, e := d.item()
			if e != nil {
				return nil, e
			}
			a = append(a, x)
		}
		return a, nil
	case 5:
		m := CBORMap{}
		var prev []byte
		for i := 0; i < int(arg); i++ {
			start := d.pos
			kAny, e := d.item()
			if e != nil {
				return nil, e
			}
			encKey := append([]byte(nil), d.data[start:d.pos]...)
			if prev != nil && (len(encKey) < len(prev) || (len(encKey) == len(prev) && bytes.Compare(encKey, prev) <= 0)) {
				return nil, CBORError{"map keys are duplicate or not deterministic"}
			}
			prev = encKey
			k, ok := kAny.(int64)
			if !ok {
				return nil, CBORError{"reference profile requires integer map keys"}
			}
			if _, exists := m[k]; exists {
				return nil, CBORError{"duplicate map key"}
			}
			val, e := d.item()
			if e != nil {
				return nil, e
			}
			m[k] = val
		}
		return m, nil
	default:
		return nil, CBORError{fmt.Sprintf("unsupported major type %d", major)}
	}
}

func DecodeCBOR(data []byte) (any, error) {
	if len(data) == 0 {
		return nil, CBORError{"empty CBOR"}
	}
	d := &cborDecoder{data: data}
	v, err := d.item()
	if err != nil {
		return nil, err
	}
	if d.pos != len(data) {
		return nil, CBORError{"trailing data"}
	}
	re, err := EncodeCBOR(v)
	if err != nil {
		return nil, err
	}
	if !bytes.Equal(re, data) {
		return nil, CBORError{"input is not deterministically encoded"}
	}
	return v, nil
}

func IsCBORError(err error) bool { var e CBORError; return errors.As(err, &e) }
